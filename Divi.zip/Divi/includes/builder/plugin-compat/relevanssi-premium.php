<?php // phpcs:disable Squiz.Commenting.FileComment.Missing -- Not used in other compat classes.
if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}

/**
 * Load the same plugin compat class.
 */
require_once 'relevanssi.php';
