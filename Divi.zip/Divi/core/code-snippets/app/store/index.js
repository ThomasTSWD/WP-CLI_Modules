// Internal dependencies.
import codeSnippetsLibrary from './code-snippets-library/module';


export default codeSnippetsLibrary;
