jQuery(document).ready(function($) {


});
//---jQuery ends--------------------------------------	