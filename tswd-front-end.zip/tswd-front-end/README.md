# tswd-front-end

Import de tswd-front-css, fontFace.css et tswd-front-js

Monokai Thm / SVG Support / Agent BodyClass

Urls & ID's in listing / Duplicate posts

[lorem x=300] [year]

CTRL+S / Admin Notes / Server infos...

![Image description](https://dev.tswd.fr/wp-content/plugins/tswd-front-end/core//dist/More-Info.jpg)
