# tswd-front-end

Import de front-css, font-face et front-js

Monokai Thème / SVG Support / Agent BodyClass

Urls & ID's in listing / Duplicate posts

[lorem x=300] [year]

CTRL+S / Admin Notes 

![Image description](https://dev.tswd.fr/wp-content/plugins/tswd-front-end/core//dist/More-Info.jpg)
